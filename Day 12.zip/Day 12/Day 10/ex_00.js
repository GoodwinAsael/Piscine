async function helloWorld() {
    return "Hello World !";
}

helloWorld().then(console.log);
